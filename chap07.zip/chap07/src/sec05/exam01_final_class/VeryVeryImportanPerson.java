package sec05.exam01_final_class;

// The type VeryVeryImportanPerson cannot subclass the final class Member
//public class VeryVeryImportanPerson extends Member {
public class VeryVeryImportanPerson {

}
