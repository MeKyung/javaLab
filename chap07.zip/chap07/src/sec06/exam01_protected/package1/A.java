package sec06.exam01_protected.package1;

public class A {
	protected String field;
	
	protected A() {
		
	}

	protected void method() {
		
	}

}
