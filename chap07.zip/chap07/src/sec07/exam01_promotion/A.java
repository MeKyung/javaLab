package sec07.exam01_promotion;

public class A {

}
