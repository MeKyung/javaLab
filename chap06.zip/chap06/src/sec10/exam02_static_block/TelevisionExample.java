package sec10.exam02_static_block;

public class TelevisionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Television.info);

	}

}
