package sec12.exam01_package_compile;

import java.util.Scanner;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("���ø����̼��� �����մϴ�.");
		
		//java.util.Scanner sc = new java.util.Scanner(System.in);
		Scanner sc = new Scanner(System.in);

	}

}
