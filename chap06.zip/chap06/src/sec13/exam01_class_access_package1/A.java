package sec13.exam01_class_access_package1;

class A {

}
