package sec07.exam01_constructor_declaration;

public class CarExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car myCar = new Car("����", 3000);
		
		Car myCar2 = new Car();  // The constructor Car() is undefined

	}

}
