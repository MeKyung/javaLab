package sec07.exam03_constructor_overloading;

public class CarExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car1 = new Car();
		System.out.println("car1.company="+car1.compnay);
		System.out.println("car1.model="+car1.model);
		
		Car car2 = new Car("�ڰ���");
		System.out.println("car2.company="+car2.compnay);
		System.out.println("car2.model="+car2.model);
		System.out.println("car2.color="+car2.color);  // null
		
		Car car3 = new Car("�ڰ���","����");
		System.out.println("car3.company="+car3.compnay);
		System.out.println("car3.model="+car3.model);
		System.out.println("car3.color="+car3.color);  // "����"
		System.out.println("car3.maxSpeed="+car3.maxSpeed);  // 0
		
		Car car4 = new Car("�ý�", "����", 200);
		System.out.println("car4.company="+car4.compnay);
		System.out.println("car4.model="+car4.model);  // "�ý�"
		System.out.println("car4.color="+car4.color);  // "����"
		System.out.println("car4.maxSpeed="+car4.maxSpeed);  // 200

	}

}
